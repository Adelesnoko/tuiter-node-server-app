export default [
    { "username": "alice",   "type": "FACULTY", "_id": "123" },
    { "username": "bob",     "type": "STUDENT", "_id": "234", "password": "2345"},
    { "username": "charlie", "type": "FACULTY", "_id": "345" }
]
  